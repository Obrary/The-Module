Product: The Module, September 2014

Designers: Barcelona FabLab team of Ruxandra Iancu Bratosin, Gokhan Catikkis, Hriday Siddarth Saini, Maria Czajczynska, Rodion Eremeev

Support:  http://forums.obrary.com/category/designs/the-module

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary is a marketplace of products collaboratively designed by the community. These products can be produced by anyone, amateur or professional manufacturer, wherever economically or locally practical.

Description:
The Module is designed to be cut on a Laser Cutter from plywood or MDF.